function comSlider1708127() { 
var self = this; 
var g_HostRoot = "";
var jssor_slider1708127 = null;var _fcarr = [{imgid: 1084663,id: 124573, fabric:{"b":{"x":49,"y":87,"w":268.90999443054193,"h":83.49000000000001,"b":0},"j":{"csfp_playin_ct":"T","csfp_playin_d":0,"csfp_playin_du":1500,"csfp_playin_co":{"fade":true,"roll":false,"clip":false,"rotatex":false,"rotatey":false,"scale":false},"csfp_playout_ct":"L","csfp_playout_d":0,"csfp_playout_du":1500,"csfp_playout_mode":2,"csfp_playout_co":{"fade":true,"roll":false,"clip":false,"rotatex":false,"rotatey":false,"scale":false},"csfp_advanced_onall":0},"s":"<svg>\t<g transform=\"translate(134.45 41.74)\">\n\t\t<text xml:space=\"preserve\" font-family=\"Source Sans Pro\" font-size=\"73\" font-style=\"normal\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(238,238,238); fill-rule: nonzero; opacity: 1; white-space: pre;\" ><tspan x=\"-133.95\" y=\"22.93\" >50% OFF</tspan></text>\n\t</g>\n</svg>","a":{}}, idle:0},{imgid: 1084663,id: 124575, fabric:{"b":{"x":113,"y":182,"w":264.8999996185303,"h":29.25,"b":0},"j":{"csfp_playin_ct":"none","csfp_playin_d":1200,"csfp_playin_du":1500,"csfp_playin_co":{"fade":true,"roll":false,"clip":false,"rotatex":false,"rotatey":false,"scale":false},"csfp_playout_ct":"L","csfp_playout_d":0,"csfp_playout_du":1500,"csfp_playout_mode":2,"csfp_playout_co":{"fade":true,"roll":false,"clip":false,"rotatex":false,"rotatey":false,"scale":false},"csfp_advanced_onall":0},"s":"<svg>\t<g transform=\"translate(132.45 14.63)\">\n\t\t<text xml:space=\"preserve\" font-family=\"Julius Sans One\" font-size=\"25\" font-style=\"normal\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1; white-space: pre;\" ><tspan x=\"-131.95\" y=\"7.85\" >NEW FALL OUTWEAR</tspan></text>\n\t</g>\n</svg>","a":{}}, idle:0},{imgid: 1084663,id: 124574, fabric:{"b":{"x":88.00000000000001,"y":400,"w":146.84000000000003,"h":46,"b":0},"j":{"csfp_playin_ct":"none","csfp_playin_d":1000,"csfp_playin_du":1500,"csfp_playin_co":{"fade":true,"roll":false,"clip":false,"rotatex":false,"rotatey":false,"scale":false},"csfp_playout_ct":"none","csfp_playout_d":0,"csfp_playout_du":1500,"csfp_playout_mode":2,"csfp_playout_co":{"fade":true,"roll":false,"clip":false,"rotatex":false,"rotatey":false,"scale":false},"csfp_advanced_onall":0},"s":"<svg><g transform=\"translate(73.42 23)\" style=\"\">\n\t<rect x=\"-71.92\" y=\"-21.5\" rx=\"0\" ry=\"0\" width=\"143.84\" height=\"43\" style=\"stroke: rgb(255,255,255); stroke-opacity: 0.85; stroke-width: 2; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-opacity: 0; fill-rule: nonzero; opacity: 1;\" transform=\"translate(-0.5 -0.5)\"/>\n\t\t<g transform=\"translate(-2.08 1.04)\">\n\t\t<text xml:space=\"preserve\" font-family=\"Source Sans Pro\" font-size=\"25\" font-style=\"normal\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.85; white-space: pre;\" ><tspan x=\"-58.84\" y=\"6.44\" >SHOP NOW</tspan></text>\n\t</g>\n</g>\n</svg>","a":{"t":"cSButton","h":{"c":null,"s":"rgba(255,255,255, 1)"},"o":{"c":"rgba(255,255,255, 0)","s":"rgba(255,255,255, 0.85)"},"u":{"u":"","t":"slidenext"}}}, idle:0},{imgid: 1084664,id: 124578, fabric:{"b":{"x":142.56,"y":87,"w":164.1279992675781,"h":28.120000000000005,"b":0},"j":{"csfp_playin_ct":"L","csfp_playin_d":1000,"csfp_playin_du":500,"csfp_playin_co":{"fade":true,"roll":false,"clip":false,"rotatex":false,"rotatey":false,"scale":false},"csfp_playout_ct":"L","csfp_playout_d":0,"csfp_playout_du":1500,"csfp_playout_mode":2,"csfp_playout_co":{"fade":true,"roll":false,"clip":false,"rotatex":false,"rotatey":false,"scale":false},"csfp_advanced_onall":0},"s":"<svg>\t<g transform=\"translate(82.06 14.06)\">\n\t\t<text xml:space=\"preserve\" font-family=\"Source Sans Pro\" font-size=\"24\" font-style=\"normal\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1; white-space: pre;\" ><tspan x=\"-81.56\" y=\"7.54\" >END OF SEASON</tspan></text>\n\t</g>\n</svg>","a":{}}, idle:0},{imgid: 1084664,id: 124577, fabric:{"b":{"x":74,"y":101.99999999999999,"w":301.7150052261353,"h":155.80999999999995,"b":0},"j":{"csfp_playin_ct":"none","csfp_playin_d":0,"csfp_playin_du":1000,"csfp_playin_co":{"fade":true,"roll":false,"clip":true,"rotatex":false,"rotatey":false,"scale":false},"csfp_playout_ct":"L","csfp_playout_d":0,"csfp_playout_du":1500,"csfp_playout_mode":2,"csfp_playout_co":{"fade":true,"roll":false,"clip":false,"rotatex":false,"rotatey":false,"scale":false},"csfp_advanced_onall":0},"s":"<svg>\t<g transform=\"translate(150.86 77.91)\">\n\t\t<text xml:space=\"preserve\" font-family=\"Source Sans Pro\" font-size=\"137\" font-style=\"normal\" font-weight=\"700\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1; white-space: pre;\" ><tspan x=\"-150.36\" y=\"43.04\" >SALE</tspan></text>\n\t</g>\n</svg>","a":{}}, idle:0},{imgid: 1084664,id: 124579, fabric:{"b":{"x":37.56,"y":249,"w":405.8799981689453,"h":28.120000000000005,"b":0},"j":{"csfp_playin_ct":"L","csfp_playin_d":1000,"csfp_playin_du":500,"csfp_playin_co":{"fade":true,"roll":false,"clip":false,"rotatex":false,"rotatey":false,"scale":false},"csfp_playout_ct":"L","csfp_playout_d":0,"csfp_playout_du":1500,"csfp_playout_mode":2,"csfp_playout_co":{"fade":true,"roll":false,"clip":false,"rotatex":false,"rotatey":false,"scale":false},"csfp_advanced_onall":0},"s":"<svg>\t<g transform=\"translate(202.94 14.06)\">\n\t\t<text xml:space=\"preserve\" font-family=\"Julius Sans One\" font-size=\"24\" font-style=\"normal\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1; white-space: pre;\" ><tspan x=\"-202.44\" y=\"7.54\" >Up to 50% off on all products</tspan></text>\n\t</g>\n</svg>","a":{}}, idle:0},{imgid: 1084664,id: 124576, fabric:{"b":{"x":154,"y":371,"w":144.82,"h":46,"b":0},"j":{"csfp_playin_ct":"L","csfp_playin_d":0,"csfp_playin_du":1500,"csfp_playin_co":{"fade":true,"roll":false,"clip":false,"rotatex":false,"rotatey":false,"scale":false},"csfp_playout_ct":"none","csfp_playout_d":0,"csfp_playout_du":1500,"csfp_playout_mode":2,"csfp_playout_co":{"fade":true,"roll":false,"clip":false,"rotatex":false,"rotatey":false,"scale":false},"csfp_advanced_onall":0},"s":"<svg><g transform=\"translate(72.41 23)\" style=\"\">\n\t<rect x=\"-70.91\" y=\"-21.5\" rx=\"0\" ry=\"0\" width=\"141.82\" height=\"43\" style=\"stroke: rgb(255,255,255); stroke-opacity: 0.85; stroke-width: 2; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-opacity: 0; fill-rule: nonzero; opacity: 1;\" transform=\"translate(-0.5 -0.5)\"/>\n\t\t<g transform=\"translate(-1.07 -0.38)\">\n\t\t<text xml:space=\"preserve\" font-family=\"Source Sans Pro\" font-size=\"25\" font-style=\"normal\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.85; white-space: pre;\" ><tspan x=\"-58.84\" y=\"7.85\" >SHOP NOW</tspan></text>\n\t</g>\n</g>\n</svg>","a":{"t":"cSButton","h":{"c":null,"s":"rgba(255,255,255, 1)"},"o":{"c":"rgba(255,255,255, 0)","s":"rgba(255,255,255, 0.85)"},"u":{"u":"","t":"slidenext"}}}, idle:0},{imgid: 1084665,id: 124580, fabric:{"b":{"x":214.67000000000002,"y":125.49000000000001,"w":529.1199999999999,"h":317.87,"b":1},"j":{"csfp_playin_ct":"none","csfp_playin_d":0,"csfp_playin_du":500,"csfp_playin_co":{"fade":true,"roll":false,"clip":false,"rotatex":false,"rotatey":false,"scale":false},"csfp_playout_ct":"none","csfp_playout_d":0,"csfp_playout_du":1500,"csfp_playout_mode":2,"csfp_playout_co":{"fade":true,"roll":false,"clip":false,"rotatex":false,"rotatey":false,"scale":false},"csfp_advanced_onall":0},"s":"<svg><rect x=\"-264.06\" y=\"-158.435\" rx=\"0\" ry=\"0\" width=\"528.12\" height=\"316.87\" style=\"stroke: rgb(255,255,255); stroke-opacity: 0.6; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-opacity: 0.4; fill-rule: nonzero; opacity: 1;\" transform=\"translate(264.56 158.94)\"/>\n</svg>","a":{}}, idle:0},{imgid: 1084665,id: 124582, fabric:{"b":{"x":413.40999999999997,"y":170,"w":123.96000213623051,"h":23.600000000000023,"b":0},"j":{"csfp_playin_ct":"none","csfp_playin_d":500,"csfp_playin_du":1000,"csfp_playin_co":{"fade":true,"roll":false,"clip":false,"rotatex":false,"rotatey":false,"scale":false},"csfp_playout_ct":"none","csfp_playout_d":0,"csfp_playout_du":1500,"csfp_playout_mode":2,"csfp_playout_co":{"fade":true,"roll":false,"clip":false,"rotatex":false,"rotatey":false,"scale":false},"csfp_advanced_onall":0},"s":"<svg>\t<g transform=\"translate(61.98 11.8)\">\n\t\t<text xml:space=\"preserve\" font-family=\"Source Sans Pro\" font-size=\"20\" font-style=\"normal\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1; white-space: pre;\" ><tspan x=\"-61.48\" y=\"6.28\" >NEW ARRIVALS</tspan></text>\n\t</g>\n</svg>","a":{}}, idle:0},{imgid: 1084665,id: 124581, fabric:{"b":{"x":356,"y":178,"w":246.14601200103766,"h":137.73000000000002,"b":0},"j":{"csfp_playin_ct":"none","csfp_playin_d":500,"csfp_playin_du":1500,"csfp_playin_co":{"fade":true,"roll":true,"clip":false,"rotatex":false,"rotatey":false,"scale":false},"csfp_playout_ct":"none","csfp_playout_d":0,"csfp_playout_du":1500,"csfp_playout_mode":2,"csfp_playout_co":{"fade":true,"roll":false,"clip":false,"rotatex":false,"rotatey":false,"scale":false},"csfp_advanced_onall":0},"s":"<svg>\t<g transform=\"translate(123.07 68.87)\">\n\t\t<text xml:space=\"preserve\" font-family=\"Source Sans Pro\" font-size=\"121\" font-style=\"normal\" font-weight=\"700\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1; white-space: pre;\" ><tspan x=\"-122.57\" y=\"38.01\" >NEW</tspan></text>\n\t</g>\n</svg>","a":{}}, idle:0},{imgid: 1084665,id: 124583, fabric:{"b":{"x":368,"y":330,"w":88,"h":46,"b":0},"j":{"csfp_playin_ct":"none","csfp_playin_d":500,"csfp_playin_du":1000,"csfp_playin_co":{"fade":true,"roll":false,"clip":false,"rotatex":false,"rotatey":false,"scale":false},"csfp_playout_ct":"none","csfp_playout_d":0,"csfp_playout_du":1500,"csfp_playout_mode":2,"csfp_playout_co":{"fade":true,"roll":false,"clip":false,"rotatex":false,"rotatey":false,"scale":false},"csfp_advanced_onall":0},"s":"<svg><g transform=\"translate(44 23)\" style=\"\">\n\t<rect x=\"-42.5\" y=\"-21.5\" rx=\"0\" ry=\"0\" width=\"85\" height=\"43\" style=\"stroke: rgb(255,255,255); stroke-opacity: 0.85; stroke-width: 2; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-opacity: 0.3; fill-rule: nonzero; opacity: 1;\" transform=\"translate(-0.5 -0.5)\"/>\n\t\t<g transform=\"translate(0.36 -0.38)\">\n\t\t<text xml:space=\"preserve\" font-family=\"Source Sans Pro\" font-size=\"25\" font-style=\"normal\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.85; white-space: pre;\" ><tspan x=\"-31.86\" y=\"7.85\" >MEN&apos;s</tspan></text>\n\t</g>\n</g>\n</svg>","a":{"t":"cSButton","h":{"c":"rgba(255,255,255,0.4)","s":"rgba(255,255,255, 1)"},"o":{"c":"rgba(255,255,255,0.3)","s":"rgba(255,255,255, 0.85)"},"u":{"u":"","t":"slidenext"}}}, idle:0},{imgid: 1084665,id: 124584, fabric:{"b":{"x":473,"y":330,"w":124,"h":46,"b":0},"j":{"csfp_playin_ct":"none","csfp_playin_d":500,"csfp_playin_du":1000,"csfp_playin_co":{"fade":true,"roll":false,"clip":false,"rotatex":false,"rotatey":false,"scale":false},"csfp_playout_ct":"none","csfp_playout_d":0,"csfp_playout_du":1500,"csfp_playout_mode":2,"csfp_playout_co":{"fade":true,"roll":false,"clip":false,"rotatex":false,"rotatey":false,"scale":false},"csfp_advanced_onall":0},"s":"<svg><g transform=\"translate(62 23)\" style=\"\">\n\t<rect x=\"-60.5\" y=\"-21.5\" rx=\"0\" ry=\"0\" width=\"121\" height=\"43\" style=\"stroke: rgb(255,255,255); stroke-opacity: 0.85; stroke-width: 2; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-opacity: 0.3; fill-rule: nonzero; opacity: 1;\" transform=\"translate(-0.5 -0.5)\"/>\n\t\t<g transform=\"translate(0.41 -0.38)\">\n\t\t<text xml:space=\"preserve\" font-family=\"Source Sans Pro\" font-size=\"25\" font-style=\"normal\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.85; white-space: pre;\" ><tspan x=\"-49.91\" y=\"7.85\" >WOMEN&apos;s</tspan></text>\n\t</g>\n</g>\n</svg>","a":{"t":"cSButton","h":{"c":"rgba(255,255,255,0.4)","s":"rgba(255,255,255, 1)"},"o":{"c":"rgba(255,255,255,0.3)","s":"rgba(255,255,255, 0.85)"},"u":{"u":"","t":"slidenext"}}}, idle:0}];	this.jssor_slider1708127_starter = function (containerId) { 
						
            var _SlideshowTransitions = [ 
{$Duration:700,$Opacity:2,$Brother:{$Duration:1000,$Opacity:2}}
				]; _slideoTransitions1708127 = null;

					var jssorCap = new csJssorCap$1708127("jqCS1708127");
					jssorCap.setContainerId("1708127");
					jssorCap.setMaxIdx("2");

					var idleperimg = new Array();
					for (var i = 0; i < _fcarr.length; i++)
					{
						var fabric = _fcarr[i].fabric;													
						var idlepercaption = jssorCap.getIdle(fabric.j, ((_fcarr[i].idle > 0) ? _fcarr[i].idle : 8000));						
						var idx = null;
						for (var j = 0; j < idleperimg.length; j++) {
							if (idleperimg[j].imgid == _fcarr[i].imgid) {
								idx = j;
								break;
							}
						}
						if (idx === null){
							idleperimg.push({imgid: _fcarr[i].imgid, idle: idlepercaption});
						} else if (idlepercaption < idleperimg[idx].idle) {
							idleperimg[idx] = idlepercaption;
						}
					}
					
					var _fcaction = new Array();
					for (var i = 0; i < _fcarr.length; i++)
					{					
						var fabric = _fcarr[i].fabric;	
						var transitiontime = ((_fcarr[i].idle > 0) ? _fcarr[i].idle : 8000);
						var tmpcap = jssorCap.composeSVGCaption(fabric.j, fabric.b, fabric.a, fabric.s, 960, 540, transitiontime, 0, "");						
						var playcaptionhtml = tmpcap.html;
						_fcaction.push({idx: tmpcap.idx, fabrica: fabric.a}); 
						jqCS1708127("#comSContainer1708127_ .fc"+_fcarr[i].id).replaceWith(playcaptionhtml);
					}
								
					for (var i = 0; i < idleperimg.length; i++){
						var pimg = jqCS1708127("#imgidle_1708127_"+idleperimg[i].imgid);
						if (pimg.length){
							pimg.attr("idle", idleperimg[i].idle);
						}
					}
				
					_slideoTransitions1708127 = jssorCap.getSlideoTransitions();
				
			
					var options = {
										$AutoPlay: true,                                   //[Optional] Whether to auto play, to enable slideshow, this option must be set to true, default value is false
										$Idle: 0,
										$LazyLoading: 1,
										$PlayOrientation: 1,                                //[Optional] Orientation to play slide (for auto play, navigation), 1 horizental, 2 vertical, default value is 1
										$DragOrientation: 1,                                //[Optional] Orientation to drag slide, 0 no drag, 1 horizental, 2 vertical, 3 either, default value is 1 (Note that the $DragOrientation should be the same as $PlayOrientation when $DisplayPieces is greater than 1, or parking position is not 0)
										$FillMode: 1,										//[Optional] The way to fill image in slide, 0: stretch, 1: contain (keep aspect ratio and put all inside slide), 2: cover (keep aspect ratio and cover whole slide), 4: actual size, 5: contain for large image and actual size for small image, default value is 0 
										$Loop: 1,										//[Optional] Enable loop(circular) of carousel or not, 0: stop, 1: loop, 2 rewind, default value is 1 
										$PauseOnHover: 0, 							//[Optional] Whether to pause when mouse over if a slider is auto playing, 0: no pause, 1: pause for desktop, 2: pause for touch device, 3: pause for desktop and touch device, 4: freeze for desktop, 8: freeze for touch device, 12: freeze for desktop and touch device, default value is 1 
										$StartIndex: 0,	//[Optional] Index of slide to display when initialize, default value is 0 
 
									$SlideshowOptions: {                                //[Optional] Options to specify and enable slideshow or not
										$Class: $JssorSlideshowRunner$,                 //[Required] Class to create instance of slideshow
										$Transitions: _SlideshowTransitions,            //[Required] An array of slideshow transitions to play slideshow
										$TransitionsOrder: 0,       //[Optional] The way to choose transition to play slide, 1 Sequence, 0 Random
									}										
						, $BulletNavigatorOptions: {                                //[Optional] Options to specify and enable navigator or not
						$Class: $JssorBulletNavigator$,                       //[Required] Class to create navigator instance
						$ChanceToShow: 2,                               //[Required] 0 Never, 1 Mouse Over, 2 Always
						$AutoCenter: 1,                                 //[Optional] Auto center navigator in parent container, 0 None, 1 Horizontal, 2 Vertical, 3 Both, default value is 0
						$Steps: 1,                                      //[Optional] Steps to go for each navigation request, default value is 1
						$Lanes: 1,                                      //[Optional] Specify lanes to arrange items, default value is 1
						$SpacingX: 10,                                   //[Optional] Horizontal space between each item in pixel, default value is 0
						$SpacingY: 10,                                   //[Optional] Vertical space between each item in pixel, default value is 0
						$Orientation: 1                                 //[Optional] The orientation of the navigator, 1 horizontal, 2 vertical, default value is 1
					}
					, $CaptionSliderOptions: {                            //[Optional] Options which specifies how to animate caption
						$Class: $JssorCaptionSlideo$,                   //[Required] Class to create instance to animate caption
						$Transitions: _slideoTransitions1708127       //[Required] An array of caption transitions to play caption, see caption transition section at jssor slideshow transition builder
					}						
									};

									self.jssor_slider1708127 = new $JssorSlider$(containerId, options);										
									
															
									var bindfc = function() {
										for(var j = 0; j < _fcaction.length; j++)
										{
											var fcacton = _fcaction[j];
											jssorCap.bindSVGCaption(fcacton.idx, fcacton.fabrica, jqCS1708127, self.jssor_slider1708127, "");												
										}
									};
									self.jssor_slider1708127.$On($JssorSlider$.$EVT_PARK, function(){bindfc();});
									}; 
							
									//responsive code begin
									//you can remove responsive code if you do not want the slider scales while window resizes
									this.ScaleSlider = function() {		
										var  parentWidth = jqCS1708127("#comSContainer1708127_").parent().width();
										if (parentWidth) {
											self.jssor_slider1708127.$ScaleWidth(Math.min(parentWidth, 960));
										}
										else
											window.setTimeout(self.ScaleSlider, 30);											
									};
				
					this.scriptLoaded = function(options)
					{
				
						if ((typeof options == "undefined") || ((typeof options != "undefined") && (typeof options.fontsloaded != "undefined") && (options.fontsloaded == false)))
						{
							var thiz = this;
							if (typeof WebFont$1708127 != "undefined")
							{
								WebFont$1708127.load({
								google: { families: ["Julius Sans One::latin,latin-ext","Source Sans Pro:400,400italic,700,700italic:latin,latin-ext","Ubuntu:400,400italic,700,700italic:latin,latin-ext","Julius Sans One::latin,latin-ext","Source Sans Pro:400,400italic,700,700italic:latin,latin-ext","Ubuntu:400,400italic,700,700italic:latin,latin-ext","Julius Sans One::latin,latin-ext","Source Sans Pro:400,400italic,700,700italic:latin,latin-ext"] },
								active: function(){	
										thiz.scriptLoaded({fontsloaded: true});						
									},
								inactive: function(){}									
								});									
								return false;
							}
							else
							{
								var loadRetries = 3;
								if ((typeof options != "undefined") && (typeof options.loadRetries != "undefined"))
									loadRetries = options.loadRetries;
								if (loadRetries > 0)
								{
									setTimeout(function(){thiz.scriptLoaded({fontsloaded: false, loadRetries: (loadRetries-1)});}, (4-loadRetries)*100);									
									return false;
								}
							}
						}
					   jqCS1708127 = jQuery1708127.noConflict(false);jqCS1708127("#comslider_in_point_1708127").html('<div id="comSContainer1708127_" name="comSContainer1708127_" style="display: inline-block; text-align: left;  border:0px; width:960px; height:540px; position: relative; top: 0px; left: 0px;"><div u="slides" style="position: absolute; left: 0px; top: 0px; width:960px; height:540px; overflow: hidden;"><div idle="8000" id="imgidle_1708127_1084663"><img u="image" src="comslider1708127/img/180405091133101.jpg"></img><div class="flyingcaption fc124573"></div><div class="flyingcaption fc124575"></div><div class="flyingcaption fc124574"></div></div><div idle="8000" id="imgidle_1708127_1084664"><img u="image" src="comslider1708127/img/180405091133102.jpg"></img><div class="flyingcaption fc124578"></div><div class="flyingcaption fc124577"></div><div class="flyingcaption fc124579"></div><div class="flyingcaption fc124576"></div></div><div idle="8000" id="imgidle_1708127_1084665"><img u="image" src="comslider1708127/img/180405091133103.jpg"></img><div class="flyingcaption fc124580"></div><div class="flyingcaption fc124582"></div><div class="flyingcaption fc124581"></div><div class="flyingcaption fc124583"></div><div class="flyingcaption fc124584"></div></div><div u="any" class="cmspu" style="display:block; position:absolute; top:10px; right:10px; width:32px; height:32px;"><a target="_blank" href="http://www.comslider.com"><img src="comslider1708127/imgstatic/cmswatermark.png"/></a></div></div><!-- Bullet Navigator Skin Begin --><!-- jssor slider bullet navigator skin 01 --><style>	/*	.	 div           (normal)	.jssorb1708127 div:hover     (normal mouseover)	.jssorb1708127 .av           (active)	.jssorb1708127 .av:hover     (active mouseover)	.jssorb1708127 .dn           (mousedown)	*/	.jssorb1708127 div, .jssorb1708127 div:hover, .jssorb1708127 .av {		filter: alpha(opacity=90);		opacity: 0.9;		overflow: hidden;		cursor: pointer;	border-radius: 24px;  border: 0px solid transparent;	background-color: transparent;		margin: 0px !important;	}	.jssorb1708127 div {		margin: 0px !important;		background-image: url(comslider1708127/imgnav/nav2.png?timstamp=1541805810);		background-repeat:no-repeat;		background-position:center; 	}		.jssorb1708127 div:hover, 		.jssorb1708127 .av:hover {  border: 0px solid transparent;	background-color: transparent;		margin: 0px !important;		background-image: url(comslider1708127/imgnav/navs2.png?timstamp=1541805810);		background-repeat:no-repeat;		background-position:center; 		}	.jssorb1708127 .av {		background-color: transparent;  border: 0px solid transparent;	background-color: transparent;		margin: 0px !important;		background-image: url(comslider1708127/imgnav/navs2.png?timstamp=1541805810);		background-repeat:no-repeat;		background-position:center; 	}</style><!-- bullet navigator container -->         <div u="navigator" class="jssorb1708127" style="position: absolute; bottom: 20px; left: 10px;">        	<!-- bullet navigator item prototype -->        	<div u="prototype" style="POSITION: absolute; WIDTH: 12px; HEIGHT: 12px;"></div>        </div>				 <!-- Bullet Navigator Skin End -->	</div>');
                    jqCS1708127("#comslider_in_point_1708127 a").bind('click',  function() { if ((this.name.length > 0) && (isNaN(this.name) == false)) {  self.switchToFrame(parseInt(this.name)); return false;} });
                
					self.jssor_slider1708127_starter("comSContainer1708127_");
							
						self.ScaleSlider();
						jqCS1708127(document).ready(function() {				
							self.ScaleSlider();
						});
						jqCS1708127(window).bind("load", self.ScaleSlider);
						jqCS1708127(window).bind("resize", self.ScaleSlider);
						jqCS1708127(window).bind("orientationchange", self.ScaleSlider);						
					
}
var g_CSIncludes = new Array();
var g_CSLoading = false;
var g_CSCurrIdx = 0; 
 this.include = function(src, last) 
                {
                    if (src != '')
                    {				
                            var tmpInclude = Array();
                            tmpInclude[0] = src;
                            tmpInclude[1] = last;					
                            //
                            g_CSIncludes[g_CSIncludes.length] = tmpInclude;
                    }            
                    if ((g_CSLoading == false) && (g_CSCurrIdx < g_CSIncludes.length))
                    {


                            var oScript = null;
                            if (g_CSIncludes[g_CSCurrIdx][0].split('.').pop().substring(0,3) == 'css')
                            {
                                oScript = document.createElement('link');
                                oScript.href = g_CSIncludes[g_CSCurrIdx][0];
                                oScript.type = 'text/css';
                                oScript.rel = 'stylesheet';

                                oScript.onloadDone = true; 
                                g_CSLoading = false;
                                g_CSCurrIdx++;								
                                if (g_CSIncludes[g_CSCurrIdx-1][1] == true) 
                                        self.scriptLoaded(); 
                                else
                                        self.include('', false);
                            }
                            else
                            {
                                oScript = document.createElement('script');
                                oScript.src = g_CSIncludes[g_CSCurrIdx][0];
                                oScript.type = 'text/javascript';

                                //oScript.onload = scriptLoaded;
                                oScript.onload = function() 
                                { 
                                        if ( ! oScript.onloadDone ) 
                                        {
                                                oScript.onloadDone = true; 
                                                g_CSLoading = false;
                                                g_CSCurrIdx++;								
                                                if (g_CSIncludes[g_CSCurrIdx-1][1] == true) 
                                                        self.scriptLoaded(); 
                                                else
                                                        self.include('', false);
                                        }
                                };
                                oScript.onreadystatechange = function() 
                                { 
                                        if ( ( "loaded" === oScript.readyState || "complete" === oScript.readyState ) && ! oScript.onloadDone ) 
                                        {
                                                oScript.onloadDone = true;
                                                g_CSLoading = false;	
                                                g_CSCurrIdx++;
                                                if (g_CSIncludes[g_CSCurrIdx-1][1] == true) 
                                                        self.scriptLoaded(); 
                                                else
                                                        self.include('', false);
                                        }
                                }
                                
                            }
                            //
                            document.getElementsByTagName("head").item(0).appendChild(oScript);
                            //
                            g_CSLoading = true;
                    }

                }
                

}
objcomSlider1708127 = new comSlider1708127();
objcomSlider1708127.include('comslider1708127/js/cmswebfont.js?ts=1541805811', false);
objcomSlider1708127.include('comslider1708127/js/jquery-1.10.1.js?ts=1541805811', false);
objcomSlider1708127.include('comslider1708127/js/jquery-ui-1.10.3.effects.js?ts=1541805811', false);
objcomSlider1708127.include('comslider1708127/js/jssor.slider.min_2_0.js?ts=1541805811', false);
objcomSlider1708127.include('comslider1708127/js/jssorcap.min.js?ts=1541805811', true);
